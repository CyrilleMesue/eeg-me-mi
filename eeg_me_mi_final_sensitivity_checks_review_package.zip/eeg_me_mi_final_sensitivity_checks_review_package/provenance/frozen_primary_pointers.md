# Frozen primary pointers

- Definitive tag: m2-preexec-fir-windows-candidate (3b615ed)
- Postdefinitive E05 tag: postdefinitive-e05-controls (bc51b62)
- Primary E01: N=102, BAcc=0.6179239767
- This package does not modify results/definitive/ or results/postdefinitive_e05/
