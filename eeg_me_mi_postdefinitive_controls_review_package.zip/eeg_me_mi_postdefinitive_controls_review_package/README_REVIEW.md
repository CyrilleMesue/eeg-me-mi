# Post-definitive E05 controls — scientific review package

Start with `postdefinitive_control_completion_report.md`.

Primary E01/E07 were not changed. See `provenance/frozen_primary_e01_e07_pointers.md`.
