# Frozen primary E01/E07 pointers (immutable)

- Tag: `m2-preexec-fir-windows-candidate`
- Commit: `3b615ed1a8e455918d6e9d90bfb5c4e42ae44adc`
- Local immutable tree: `results/definitive/full/e01/erd_lr/` and `results/definitive/full/e07/`
- Primary E01: N=102, BAcc=0.6179239767, bootstrap 95% CI [0.603553, 0.632899]
- E07: 1000/1000 permutations, observed=0.6179239767, count(null>=observed)=0, plus-one p=0.000999000999
- This package does **not** modify those definitive files.
